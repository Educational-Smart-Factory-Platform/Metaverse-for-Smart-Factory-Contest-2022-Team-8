from time import sleep
import urllib3
import json
import collections
from threading import Thread 
from firebase import firebase 
from datetime import datetime
import pytz #timezone
http    = urllib3.PoolManager()

sensor_list = list([x for x in range(10)])
responsibility = {"GREEN":2,"YELLOW":1,"RED":3,"BLUE":4,"PURPLE":0}


stat = list(0 for i in range(10))
color_list=[]
list_all = []




def gen_timestamp() -> str:
    tz_Thai = pytz.timezone('Asia/Bangkok')
    datetime_Thai = datetime.now(tz_Thai)
    return datetime_Thai.strftime("%Y-%m-%d/%H:%M:%S")

DB= firebase.FirebaseApplication("https://metaverse-factory-default-rtdb.asia-southeast1.firebasedatabase.app/", None) 


def reset():
    f1_init = {
        'color-0' : 0,
        'color-1' : 0,
        'color-2' :0,
        'color-3' :0,
        'color-4':0,
        'time-stamp': gen_timestamp() 
    }

    f2_init = {
        'material-0' : 0,
        'material-1' : 0,
        'time-stamp': gen_timestamp() 
    }

    DB.put("db-telesort","f1",f1_init)
    DB.put("db-telesort","f2",f2_init)


def push(idx):
    data_json   = {"action" : 1}
    data_encode = json.dumps(data_json).encode("utf-8")
                
    res = http.request("POST",
                        f"http://localhost/tss/0/actuator/{idx}",
                        body=data_encode,
                        headers={"Content-Type" : "application/json"})
                
    sleep(0.5)

    data_json   = {"action" : 0}
    data_encode = json.dumps(data_json).encode("utf-8")
    res = http.request("POST",
                        f"http://localhost/tss/0/actuator/{idx}",
                        body=data_encode,
                        headers={"Content-Type" : "application/json"})

def activate(color_list):
    actuator_num = responsibility[color_list[0]]
    res = http.request( "GET",
                            "http://localhost/tss/0/sensor"
                            )
    text    = res.data.decode("utf-8")
    text = json.loads(text)
    if len(color_list) == 1:
        if str(text[actuator_num]["value"])=="1":
            sleep(0.1)
            push(actuator_num)
            color_list.pop(0)
            print(color_list)
    else:
        color_list.clear()

# def get_data(telenum): 
#     data = DB.get(f"db-telesort/{telenum}",'')
#     return data

def main():
    f1_init = {
        'color-0' : 0,
        'color-1' : 0,
        'color-2' :0,
        'color-3' :0,
        'color-4':0,
        'time-stamp': gen_timestamp() 
    }


    temp = 0
    while True:
        res = http.request( "GET",
                            "http://localhost/tss/0/sensor"
                            )
        text    = res.data.decode("utf-8")
        text = json.loads(text)
        if temp==0:
            if str(text[0]["value"])=="1":
                temp = 1
                data = responsibility[str(text[10]['value'])]
                f1_init[data] = f1_init[data]+1
                DB.put("db-telesort","f1",f1_init)
                print(text[10]['value'])
                color_list.append(str(text[10]['value']))
            else:
                temp = 0
        else: temp = 0
        if len(color_list)!=0:
            activate(color_list)
        sleep(0.3)

        # check_input()
    print(colo_list)
if __name__=="__main__":
    reset()
    main()