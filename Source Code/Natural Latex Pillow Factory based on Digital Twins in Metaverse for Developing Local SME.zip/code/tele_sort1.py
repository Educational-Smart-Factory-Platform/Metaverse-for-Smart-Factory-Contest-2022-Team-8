from time import sleep
import urllib3
import json
import collections
http    = urllib3.PoolManager()

obj_list=[]

def action(t):
    sleep(t)
    data_json   = {"action" : 1}
    data_encode = json.dumps(data_json).encode("utf-8")
    
    res = http.request("POST",
                        "http://localhost/tss/1/actuator/0",
                        body=data_encode,
                        headers={"Content-Type" : "application/json"})
    

    sleep(1)

    # Deactivate
    data_json   = {"action" : 0}
    data_encode = json.dumps(data_json).encode("utf-8")
    
    res = http.request("POST",
                        "http://localhost/tss/1/actuator/0",
                        body=data_encode,
                        headers={"Content-Type" : "application/json"})


def main():
    i=0
    temp = 0
    obj = 0
    while True:
        res = http.request( "GET",
                            "http://localhost/tss/1/sensor"
                            )
        text    = res.data.decode("utf-8")
        text = json.loads(text)
        a,b= text[0]['value'], text[1]['value']
        # print(a,b,i,temp)
        if str(a) == "1":temp = 1
        if temp == 1:
            if str(b)=="1":
                obj = 1
                i=0
            if str(b) != "1" :i=i+1
            if i>7:
                obj = 2
                i = 0
        if obj != 0:
            obj_list.append(obj)
            if(obj == 1):action(0.7)
            # else: action(0.1)
            print(obj)
            obj,i,temp = 0,0,0

        sleep(0.2)

if __name__=="__main__":
    main()


# for i in data:
